From:

Kiti, M.C., Tizzoni, M., Kinyanjui, T.M. et al. Quantifying social contacts in a household setting of rural Kenya using wearable proximity sensors. EPJ Data Sci. 5, 21 (2016). https://doi.org/10.1140/epjds/s13688-016-0084-2

https://epjdatascience.springeropen.com/articles/10.1140/epjds/s13688-016-0084-2


Data downloaded from:
http://www.sociopatterns.org/datasets/kenyan-households-contact-network/